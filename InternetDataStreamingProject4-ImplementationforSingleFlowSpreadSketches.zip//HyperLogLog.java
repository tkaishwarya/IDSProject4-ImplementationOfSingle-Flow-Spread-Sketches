import java.io.*;
import java.util.*;
import java.util.Random;

public class HyperLogLog {
   int bitmap_array[] = new int[256];
   Random random = new Random();
   int resultbitmap[] = new int[256];
   double probability=0.1;
   HyperLogLog(int size){
	   //create a flow array and fill it will random values using Random instance.
	   int flow_array[] = new int[size];
	   int limit = Integer.MAX_VALUE;
       for(int i=0;i<size;i++) {
    	   flow_array[i]= Math.abs(random.nextInt(limit-1)+1);
       }
       //initialize bitmap with 0s
       for(int i=0;i<256;i++) {
    	   bitmap_array[i]=0;
       }
       resultbitmap = hashBitMap(bitmap_array, flow_array);
   }
   public int[] hashBitMap(int bitmap_array[], int flow_array[]) {
	   int hash_value = random.nextInt(Integer.MAX_VALUE);
	   for(int i=0;i<flow_array.length;i++) {
		   int hashed_val = flow_array[i]^hash_value;
		   int g = Integer.numberOfLeadingZeros(flow_array[i]);
		   int g_index = hashed_val%256;
		   bitmap_array[g_index] = Math.max(bitmap_array[g_index], g);
	   }
	   return bitmap_array;
   }
   public int calculate_spread_size() {
	   double x=0.7213/(1+(1.079/256));
		
	   int pcount=0;
		
	   double y=0;
	   double z;
		for(int i=0;i<256;i++) {
			z=Math.pow(2, resultbitmap[i]);
			y+=(1/z);
		}
		
		pcount = (int)((x)*(Math.pow(256, 2))*(1/y));
	    System.out.println(pcount);	
		return pcount;
	   
   }
   public static void main(String args[]) {
	   int spread_array[] = {1000,10000,100000,1000000};
	   try {
		    File outputFile= new File("C:\\Users\\DELL\\eclipse-workspace\\Output-HyperLogLog.txt");
	    	FileOutputStream opt= new FileOutputStream(outputFile);

	        BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(opt));

	        for (int i = 0; i <spread_array.length; i++) {
	        	HyperLogLog b=new HyperLogLog(spread_array[i]);
	            buff.write("Actual Flow Spread Size: "+ spread_array[i] + "\t Observed Flow Spread Size: "+ b.calculate_spread_size());
	            buff.newLine();
	        }
	    	
	        buff.close();
	
		}
		catch(Exception e) {
			System.out.println("Invalid File path");
		}

	}

}
