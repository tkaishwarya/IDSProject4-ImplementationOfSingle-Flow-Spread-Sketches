import java.io.*;
import java.util.*;
import java.util.Random;

public class BitMap {
   int bitmap_array[] = new int[10000];
   Random random = new Random();
   int resultbitmap[] = new int[10000];
   int bitmap_size = 10000;
   BitMap(int size){
	   //create a flow array and fill it will random values using Random instance.
	   int flow_array[] = new int[size];
	   int limit = Integer.MAX_VALUE;
       for(int i=0;i<size;i++) {
    	   flow_array[i]= Math.abs(random.nextInt(limit-1)+1);
       }
       //initialize bitmap with 0s
       for(int i=0;i<bitmap_size;i++) {
    	   bitmap_array[i]=0;
       }
       resultbitmap = hashBitMap(bitmap_array, flow_array);
   }
   public int[] hashBitMap(int bitmap_array[], int flow_array[]) {
	   int hash_value = random.nextInt(Integer.MAX_VALUE);
	   for(int i=0;i<flow_array.length;i++) {
		  int k = (flow_array[i]^hash_value)%bitmap_size;
		  bitmap_array[k]=1;
	   }
	   return bitmap_array;
   }
   
   //function to calculate flow spread size and we are converting it to integer.

   public int calculate_spread_size() {
	   double countzeroes = 0;
	   for(int i=0;i<bitmap_size;i++) {
		   if(resultbitmap[i]==0) {
			   countzeroes++;
		   }
	   }
	   int flowspread = (int)((-1)*bitmap_size*(Math.log(countzeroes/bitmap_size
			   )));
	   //Here, if we take a small bitmap size and if number of zeroes is 0 then the formula since we are using log it can lead upto Infinity. In our case since we are setting our limit to Integer.MAX_VALUE the value goes upto or reaches 2147483647 so it just shows us this output in this case.
	   return flowspread;
	   
   }
   public static void main(String args[]) {
	   int spread_array[] = {100,1000,10000,100000,1000000};
	   try {
		    File outputFile= new File("C:\\Users\\DELL\\eclipse-workspace\\Output-BitMap.txt");
	    	FileOutputStream opt= new FileOutputStream(outputFile);

	        BufferedWriter buff = new BufferedWriter(new OutputStreamWriter(opt));

	        for (int i = 0; i <spread_array.length; i++) {
	        	BitMap b=new BitMap(spread_array[i]);
	            buff.write("Actual Flow Spread Size: "+ spread_array[i] + "\t Observed Flow Spread Size: "+ b.calculate_spread_size());
	            buff.newLine();
	        }
	    	
	        buff.close();
	
		}
		catch(Exception e) {
			System.out.println("Invalid File path");
		}

	}

}
